import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PaginaInicio from './paginaInicioa';
import FormuClien from './components/FormuClien';

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/registro-cliente" element={<FormuClien />} />
                <Route path="/" element={<PaginaInicio usuario="Nombre del Usuario" />} />
            </Routes>
        </Router>
    );
};

export default App;

