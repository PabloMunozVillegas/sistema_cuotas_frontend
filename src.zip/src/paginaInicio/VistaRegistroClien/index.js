import React from 'react';
import FormuClien from './components/formuClien';

const VistaRegistroClien = () => {
    return (
        <div>
            
        </div>
    );
};

export default VistaRegistroClien;