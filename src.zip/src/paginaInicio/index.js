import React from 'react';
import Inicio from './components/inicio';
import Sidebar from './components/sidebar';

const PaginaInicio = () => {
    const [usuario, setUsuario] = React.useState('');
    return (
        <div className="flex">
            <Sidebar />
            <div className="flex-1 ml-64 max-w-full overflow-x-hidden"> {/* Agregar max-w-full y overflow-x-hidden */}
                <Inicio usuario={usuario} />
            </div>
        </div>
    );
};

export default PaginaInicio;


