import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
    return (
        <div className="sidebar">
            <ul>
                <li>
                    <Link to="/registro-cliente">Registrar Cliente</Link>
                </li>
                {/* Otros enlaces del sidebar */}
            </ul>
        </div>
    );
};

export default Sidebar;

