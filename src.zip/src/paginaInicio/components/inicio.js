import React, { useEffect, useState } from 'react';
import Sidebar from './sidebar';

const Inicio = ({ usuario }) => {
    const [dateTime, setDateTime] = useState(new Date());

    useEffect(() => {
        const intervalId = setInterval(() => {
            setDateTime(new Date());
        }, 1000);
        
        return () => clearInterval(intervalId);
    }, []);

    return (
        <div className="flex">
            <Sidebar />
            <div className="flex-1 ml-64 max-w-full overflow-x-hidden p-8 bg-white min-h-screen">
                <div className="w-full max-w-screen-lg mx-auto flex justify-between items-center mb-4">
                    <div className="text-gray-700 text-xl font-bold">
                        {usuario}
                    </div>
                    <div className="text-gray-700 text-xl">
                        {dateTime.toLocaleDateString()} {dateTime.toLocaleTimeString()}
                    </div>
                </div>
                <div className="w-full max-w-screen-lg overflow-hidden break-words">
                    <h1 className="text-4xl font-bold text-gray-700 break-words">
                        Hola Astronautas
                    </h1>
                    <p className="mt-4 break-words">
                        Aquí puedes agregar más texto o cualquier contenido adicional que necesites.
                        La idea es mantener todo dentro de este contenedor para que no se desborde.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Inicio;



